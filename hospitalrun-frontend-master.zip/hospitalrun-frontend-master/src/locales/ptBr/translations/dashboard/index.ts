export default {
  dashboard: {
    label: 'Painel de controle',
  },
}
