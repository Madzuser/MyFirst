export default {
  sex: {
    male: 'Masculino',
    female: 'Feminino',
    other: 'Outro',
    unknown: 'Desconhecido',
  },
}
