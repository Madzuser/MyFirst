export default {
  actions: {
    label: 'Ações',
    edit: 'Editar',
    save: 'Salvar',
    update: 'Atualizar',
    complete: 'Completar',
    delete: 'Eliminar',
    cancel: 'Cancelar',
    new: 'Novo',
    list: 'Lista',
    search: 'Pesquisar',
    confirmDelete: 'Eliminar confirmação',
  },
}
