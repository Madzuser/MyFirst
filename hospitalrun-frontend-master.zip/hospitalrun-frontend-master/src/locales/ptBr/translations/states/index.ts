export default {
  states: {
    success: 'Sucesso!',
    error: 'Algo deu errado..',
  },
}
