export default {
  states: {
    success: 'Successo!',
    error: 'Errore!',
  },
}
