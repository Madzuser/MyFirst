export default {
  sex: {
    male: 'Maschio',
    female: 'Femmina',
    other: 'Altro',
    unknown: 'Sconosciuto',
  },
}
