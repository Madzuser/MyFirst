export default {
  actions: {
    label: 'Azioni',
    edit: 'Modifica',
    save: 'Salva',
    update: 'Aggiorna',
    complete: 'Completa',
    delete: 'Rimuovi',
    cancel: 'Annulla',
    new: 'Nuovo',
    list: 'Lista',
    search: 'Cerca',
    confirmDelete: 'Conferma cancellazione',
  },
}
