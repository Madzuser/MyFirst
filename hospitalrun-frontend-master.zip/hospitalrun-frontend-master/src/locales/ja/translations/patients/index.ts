export default {
  patients: {
    label: '患者さん',
    viewPatients: '患者を見る',
    viewPatient: '患者を見る',
    newPatient: '新しい患者',
  },
}
