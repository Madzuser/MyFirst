export default {
  actions: {
    edit: '編集',
    save: 'セーブ',
    cancel: 'キャンセル',
    new: '新しい',
    list: 'リスト',
  },
}
