export default {
  dashboard: {
    label: 'ダッシュボード',
  },
}
