export default {
  labs: {
    lab: {
      code: '検査コード',
    },
  },
}
