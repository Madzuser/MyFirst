export default {
  patient: {
    firstName: 'ファーストネーム',
    lastName: '苗字',
  },
}
