export default {
  labs: {
    lab: {
      code: 'Código',
    },
  },
}
