export default {
  patient: {
    firstName: 'Nombre de pila',
    lastName: 'Apellido',
  },
}
