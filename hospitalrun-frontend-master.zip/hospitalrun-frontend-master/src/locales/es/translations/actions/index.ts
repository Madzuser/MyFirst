export default {
  actions: {
    edit: 'Editar',
    save: 'Guardar',
    cancel: 'Cancelar',
    new: 'Nuevo',
    list: 'Lista',
  },
}
