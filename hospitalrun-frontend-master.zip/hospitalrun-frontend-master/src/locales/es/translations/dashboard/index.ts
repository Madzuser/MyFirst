export default {
  dashboard: {
    label: 'Panel',
  },
}
