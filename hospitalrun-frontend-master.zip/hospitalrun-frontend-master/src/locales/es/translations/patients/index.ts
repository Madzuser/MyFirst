export default {
  patients: {
    label: 'Pacientes',
    viewPatients: 'Ver pacientes',
    viewPatient: 'Ver pacientes',
    newPatient: 'Nuevo paciente',
  },
}
