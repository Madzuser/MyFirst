export default {
  actions: {
    edit: '编辑',
    save: '保存',
    cancel: '取消',
    new: '新',
    list: '清单',
  },
}
