export default {
  patient: {
    firstName: '名字',
    lastName: '姓',
  },
}
