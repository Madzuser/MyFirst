export default {
  patients: {
    label: '耐心',
    viewPatients: '查看患者',
    viewPatient: '查看患者',
    newPatient: '新病人',
  },
}
