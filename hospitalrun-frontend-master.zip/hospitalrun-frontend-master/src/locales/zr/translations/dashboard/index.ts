export default {
  dashboard: {
    label: '仪表板',
  },
}
