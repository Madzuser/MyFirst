export default {
  patients: {
    label: 'المرضى',
    viewPatients: 'عرض المرضى',
    viewPatient: 'عرض المريض',
    newPatient: 'مريض جديد',
  },
}
