export default {
  actions: {
    edit: 'تصحيح',
    save: 'حفظ',
    cancel: 'إلغاء',
    new: 'الجديد',
    list: 'قائمة',
  },
}
