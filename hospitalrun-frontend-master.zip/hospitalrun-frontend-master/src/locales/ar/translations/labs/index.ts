export default {
  labs: {
    lab: {
      code: 'كود المختبر',
    },
  },
}
