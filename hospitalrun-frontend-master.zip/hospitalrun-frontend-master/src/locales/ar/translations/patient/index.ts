export default {
  patient: {
    firstName: 'الاسم الاول',
    lastName: 'الكنية',
  },
}
