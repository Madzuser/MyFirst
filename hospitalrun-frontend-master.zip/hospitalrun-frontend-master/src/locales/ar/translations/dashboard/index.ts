export default {
  dashboard: {
    label: 'لوحة القيادة',
  },
}
