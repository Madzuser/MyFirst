export default {
  labs: {
    lab: {
      code: 'Kode',
    },
  },
}
