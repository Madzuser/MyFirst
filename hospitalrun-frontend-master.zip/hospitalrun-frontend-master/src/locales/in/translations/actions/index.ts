export default {
  actions: {
    edit: 'Edit',
    save: 'Menyimpan',
    cancel: 'Membatalkan',
    new: 'Baru',
    list: 'Daftar',
  },
}
