export default {
  patient: {
    firstName: 'Nama depan',
    lastName: 'Nama keluarga',
  },
}
