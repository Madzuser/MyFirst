export default {
  dashboard: {
    label: 'Dasbor',
  },
}
