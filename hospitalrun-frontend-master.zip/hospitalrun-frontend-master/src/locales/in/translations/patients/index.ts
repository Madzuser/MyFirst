export default {
  patients: {
    label: 'Pasien',
    viewPatients: 'Lihat Pasien',
    viewPatient: 'Lihat Pasien',
    newPatient: 'Pasien Baru',
  },
}
