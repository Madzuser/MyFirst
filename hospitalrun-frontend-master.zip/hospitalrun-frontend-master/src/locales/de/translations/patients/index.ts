export default {
  patients: {
    label: 'Patienten',
    viewPatients: 'Patienten anzeigen',
    viewPatient: 'Patient anzeigen',
    newPatient: 'Neuer Patient',
  },
}
