export default {
  dashboard: {
    label: 'Instrumententafel',
  },
}
