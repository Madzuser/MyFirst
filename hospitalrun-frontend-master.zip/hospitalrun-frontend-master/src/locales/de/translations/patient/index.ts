export default {
  patient: {
    firstName: 'Vorname',
    lastName: 'Nachname',
  },
}
