export default {
  labs: {
    lab: {
      code: 'Laborcode',
    },
  },
}
