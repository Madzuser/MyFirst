export default {
  actions: {
    edit: 'Bearbeiten',
    save: 'speichern',
    cancel: 'Stornieren',
    new: 'Neu',
    list: 'Liste',
  },
}
