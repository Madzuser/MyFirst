export default {
  states: {
    success: 'Succès !',
    error: 'Erreur !',
  },
}
