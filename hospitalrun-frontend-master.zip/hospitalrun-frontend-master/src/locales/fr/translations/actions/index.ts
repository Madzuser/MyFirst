export default {
  actions: {
    label: 'Actions',
    edit: 'Éditer',
    save: 'Enregistrer',
    update: 'Mettre à jour',
    complete: 'Compléter',
    delete: 'Supprimer',
    cancel: 'Annuler',
    new: 'Nouveau',
    list: 'Liste',
    search: 'Rechercher',
    confirmDelete: 'Confirmer la suppression',
  },
}
