export default {
  dashboard: {
    label: 'Tableau de bord',
  },
}
