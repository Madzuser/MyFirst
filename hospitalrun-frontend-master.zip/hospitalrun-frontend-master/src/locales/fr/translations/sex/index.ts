export default {
  sex: {
    male: 'Homme',
    female: 'Femme',
    other: 'Autre',
    unknown: 'Inconnu',
  },
}
