export default {
  dashboard: {
    label: 'Панель приборов',
  },
}
