export default {
  patient: {
    firstName: 'Имя',
    lastName: 'Фамилия',
  },
}
