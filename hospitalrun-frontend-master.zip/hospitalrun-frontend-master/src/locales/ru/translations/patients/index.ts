export default {
  patients: {
    label: 'Пациенты',
    viewPatients: 'Просмотр пациентов',
    viewPatient: 'Просмотр пациента',
    newPatient: 'Новый пациент',
  },
}
