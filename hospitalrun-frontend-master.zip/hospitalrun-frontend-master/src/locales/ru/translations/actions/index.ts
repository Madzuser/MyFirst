export default {
  actions: {
    edit: 'редактировать',
    save: 'Сохранить',
    cancel: 'Отмена',
    new: 'новый',
    list: 'Список',
  },
}
