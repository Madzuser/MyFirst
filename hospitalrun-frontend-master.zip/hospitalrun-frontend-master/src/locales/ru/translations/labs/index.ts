export default {
  labs: {
    lab: {
      code: 'Лабораторный код',
    },
  },
}
