export default {
  dashboard: {
    label: 'Dashboard',
  },
}
