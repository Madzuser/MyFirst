export default {
  sex: {
    male: 'Male',
    female: 'Female',
    other: 'Other',
    unknown: 'Unknown',
  },
}
