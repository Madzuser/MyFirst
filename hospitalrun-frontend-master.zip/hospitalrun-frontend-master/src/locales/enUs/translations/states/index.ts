export default {
  states: {
    success: 'Success!',
    error: 'Error!',
  },
}
