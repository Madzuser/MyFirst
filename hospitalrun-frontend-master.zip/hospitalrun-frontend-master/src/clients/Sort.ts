export default interface Sort {
  field: string
  direction: 'asc' | 'desc'
}
