export default interface Note {
  id: string
  date: string
  text: string
}
