export default interface Breadcrumb {
  i18nKey?: string
  text?: string
  location: string
}
