import Name from './Name'

export default interface User extends Name {
  id: string
}
