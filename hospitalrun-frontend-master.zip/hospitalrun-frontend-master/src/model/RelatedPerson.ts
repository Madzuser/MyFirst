export default interface RelatedPerson {
  id: string
  patientId: string
  type: string
}
