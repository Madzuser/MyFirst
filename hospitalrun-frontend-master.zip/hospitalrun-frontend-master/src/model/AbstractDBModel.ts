export default interface AbstractDBModel {
  id: string
  rev: string
  createdAt: string
  updatedAt: string
}
