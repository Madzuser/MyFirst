export default interface Diagnosis {
  id: string
  name: string
  diagnosisDate: string
}
