export default interface ContactInformation {
  phoneNumber: string
  email?: string
  address?: string
}
