export default interface Name {
  prefix?: string
  givenName?: string
  familyName?: string
  suffix?: string
  fullName?: string
}
