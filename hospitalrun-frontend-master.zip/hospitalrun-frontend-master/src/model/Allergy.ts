export default interface Allergy {
  id: string
  name: string
}
